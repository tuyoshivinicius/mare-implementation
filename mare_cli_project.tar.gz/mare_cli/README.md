# MARE CLI - Multi-Agent Collaboration Framework for Requirements Engineering

Uma poderosa ferramenta de linha de comando que implementa o framework MARE para engenharia de requisitos automatizada usando agentes de IA colaborativos.

## 📚 Sobre o Projeto

Este projeto implementa o framework MARE descrito no paper "MARE: Multi-Agents Collaboration Framework for Requirements Engineering" (https://arxiv.org/abs/2405.03256). O framework utiliza cinco agentes especializados que colaboram para transformar requisitos iniciais em especificações estruturadas de software.

### 🤖 Agentes do Framework

1. **Stakeholder Agent** - Expressa necessidades dos stakeholders
2. **Collector Agent** - Coleta e refina requisitos através de questionamento
3. **Modeler Agent** - Extrai entidades e relacionamentos dos requisitos
4. **Checker Agent** - Verifica qualidade, completude e consistência
5. **Documenter Agent** - Gera especificações finais ou relatórios de problemas

### 🔄 Processo de 4 Fases

1. **Elicitação** - Captura e refinamento de necessidades
2. **Modelagem** - Estruturação e organização dos requisitos
3. **Verificação** - Validação de qualidade e consistência
4. **Especificação** - Geração de documentação final

## 🚀 Instalação

### Pré-requisitos

- Python 3.8 ou superior
- pip (gerenciador de pacotes Python)

### Instalação via pip

```bash
pip install mare-cli
```

### Instalação para Desenvolvimento

```bash
git clone https://github.com/manus-ai/mare-cli.git
cd mare-cli
pip install -e .
```

## 📖 Uso Básico

### 1. Inicializar um Novo Projeto

```bash
# Projeto básico
mare init meu_projeto

# Com template específico
mare init meu_projeto --template web_app --llm-provider openai
```

### 2. Configurar Chaves de API

Copie `.env.template` para `.env` e configure suas chaves de API:

```bash
cp .env.template .env
# Edite .env com suas chaves de API
```

### 3. Executar o Pipeline

```bash
# Execução completa
mare run

# Execução interativa
mare run --interactive

# Fase específica
mare run --phase elicitation
```

### 4. Verificar Status

```bash
# Status básico
mare status

# Status detalhado com métricas
mare status --detailed --quality
```

### 5. Exportar Resultados

```bash
# Exportar como Markdown
mare export markdown

# Exportar como PDF com metadados
mare export pdf --include-metadata --quality-report
```

## 🛠️ Comandos Disponíveis

### `mare init`
Inicializa um novo projeto MARE com estrutura e configuração padrão.

**Opções:**
- `--template`: Template do projeto (basic, web_app, mobile_app, enterprise)
- `--llm-provider`: Provedor de LLM (openai, anthropic, local)
- `--force`: Força inicialização mesmo se diretório existir

### `mare run`
Executa o pipeline multi-agente para processar requisitos.

**Opções:**
- `--phase`: Executa fase específica (elicitation, modeling, verification, specification)
- `--interactive`: Modo interativo com execução passo-a-passo
- `--input-file`: Arquivo de entrada com requisitos iniciais
- `--max-iterations`: Número máximo de iterações de refinamento

### `mare status`
Exibe informações sobre o estado atual do projeto.

**Opções:**
- `--detailed`: Mostra informações detalhadas
- `--artifacts`: Lista todos os artefatos no workspace
- `--quality`: Mostra métricas de qualidade

### `mare export`
Exporta resultados em formato especificado.

**Formatos suportados:** json, markdown, pdf, xml

**Opções:**
- `--output`: Caminho do arquivo de saída
- `--template`: Template customizado para formatação
- `--include-metadata`: Inclui metadados e rastreabilidade
- `--quality-report`: Inclui relatório de análise de qualidade

## 📁 Estrutura do Projeto

```
meu_projeto/
├── .mare/                 # Configuração e workspace do MARE
│   ├── config.yaml       # Configuração principal
│   ├── workspace/        # Artefatos e versionamento
│   └── logs/            # Logs de execução
├── input/               # Requisitos de entrada
│   └── requirements.md  # Arquivo de requisitos inicial
├── output/              # Especificações geradas
├── templates/           # Templates customizados
└── README.md           # Documentação do projeto
```

## ⚙️ Configuração

### Arquivo de Configuração Principal

O arquivo `.mare/config.yaml` contém todas as configurações do projeto:

```yaml
project:
  name: meu_projeto
  template: basic
  
llm:
  provider: openai
  models:
    default: gpt-3.5-turbo
    modeler: gpt-4
    checker: gpt-4
    
agents:
  stakeholder:
    enabled: true
    model: default
  collector:
    enabled: true
    model: default
    
pipeline:
  max_iterations: 5
  quality_threshold: 0.8
  auto_advance: true
```

### Variáveis de Ambiente

```bash
# Provedor de LLM
MARE_LLM_PROVIDER=openai

# Chaves de API
OPENAI_API_KEY=sua_chave_aqui
ANTHROPIC_API_KEY=sua_chave_aqui

# Configurações de logging
MARE_LOG_LEVEL=INFO
MARE_LOG_FILE=.mare/logs/mare.log
```

## 🎯 Exemplos de Uso

### Exemplo 1: Sistema de Gerenciamento de Tarefas

```bash
# Inicializar projeto
mare init task_manager --template basic

cd task_manager

# Editar input/requirements.md com seus requisitos
# Executar pipeline
mare run

# Verificar resultados
mare status --quality
mare export markdown --output task_requirements.md
```

### Exemplo 2: Aplicação Web E-commerce

```bash
# Inicializar com template web
mare init ecommerce_app --template web_app

cd ecommerce_app

# Executar em modo interativo
mare run --interactive

# Exportar como PDF com relatório completo
mare export pdf --include-metadata --quality-report
```

## 🔧 Desenvolvimento

### Estrutura do Código

```
mare_cli/
├── mare/
│   ├── cli/              # Interface de linha de comando
│   ├── agents/           # Implementação dos agentes
│   ├── pipeline/         # Orquestração com LangGraph
│   ├── workspace/        # Sistema de armazenamento
│   └── utils/           # Utilitários e helpers
├── tests/               # Testes automatizados
└── docs/               # Documentação
```

### Executar Testes

```bash
pytest tests/
```

### Contribuindo

1. Fork o repositório
2. Crie uma branch para sua feature (`git checkout -b feature/nova-funcionalidade`)
3. Commit suas mudanças (`git commit -am 'Adiciona nova funcionalidade'`)
4. Push para a branch (`git push origin feature/nova-funcionalidade`)
5. Abra um Pull Request

## 📄 Licença

Este projeto está licenciado sob a Licença MIT - veja o arquivo [LICENSE](LICENSE) para detalhes.

## 🙏 Agradecimentos

- Baseado no paper "MARE: Multi-Agents Collaboration Framework for Requirements Engineering" por Dongning Jin, Zhi Jin, Xiaohong Chen, e Chunhui Wang
- Utiliza LangChain e LangGraph para orquestração de agentes
- Interface CLI construída com Click e Rich

## 📞 Suporte

- **Issues**: https://github.com/manus-ai/mare-cli/issues
- **Documentação**: https://mare-cli.readthedocs.io/
- **Email**: contact@manus.ai

---

**MARE CLI v1.0.0** - Desenvolvido por Manus AI

